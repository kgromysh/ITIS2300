/*This function is called when the window is done loading*/
window.onload = function() {

	//enter in the function to be called when the button is clicked
	document.getElementById("btn1").onclick = changeImage;
	document.getElementById("btn2").onclick = changeImage2;
	document.getElementById("btn3").onclick = changeImage3;
	document.getElementById("btn4").onclick = changeStyle;
	
};

/*This function is called when the button is pressed*/
function changeImage() {

	//verifies the function is being called, you can remove this line
	
	document.getElementById("myImage").src="cutepuppy.jpg";
	
}
function changeImage2() {
	
document.getElementById("myImage").src="cutepuppy2.jpg";
}
function changeImage3() {
	
document.getElementById("myImage").src="cutepuppy3.jpg";
}

function changeStyle() {
	 document.getElementById("myImage").style.border = "10px solid white";
	 document.getElementById("m").style.backgroundColor = "gray";
	 document.getElementById("explanation").style.fontWeight = "bold";
	 document.getElementById("btn1").style.backgroundColor = "blue";
	 document.getElementById("btn2").style.backgroundColor = "blue";
	 document.getElementById("btn3").style.backgroundColor = "blue";
	 document.getElementById("btn1").style.color = "white";
	 document.getElementById("btn2").style.color = "white";
	 document.getElementById("btn3").style.color = "white";
}